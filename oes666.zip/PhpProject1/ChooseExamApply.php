<!DOCTYPE html>

<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>Login Page</title>
</head>
<body> 
    <?php
        function Redirect($url, $permanent = false)
{
    if (headers_sent() === false)
    {
    	header('Location: ' . $url, true, ($permanent === true) ? 301 : 302);
    }

    exit();
}
session_start();

        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "onlineexam";
        $conn = new mysqli($servername, $username, $password, $dbname);
        if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
        }
    
        $_SESSION["num"]= $_POST["num"];
         
        Redirect('studentexam.php', false); 
         $conn->close(); 

         

      
        
        
        
    
    
  ?>
  
</body>
</html>
