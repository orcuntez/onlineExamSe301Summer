<!DOCTYPE html>


    <?php
   
    
        function Redirect($url, $permanent = false)
{
    if (headers_sent() === false)
    {
    	header('Location: ' . $url, true, ($permanent === true) ? 301 : 302);
    }

    exit();
}
session_start();
    if($_SESSION["ssn"]==null)
        Redirect('student.php', false); 


        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "onlineexam";
        $conn = new mysqli($servername, $username, $password, $dbname);
        if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
        }
        
        $sn = $_SESSION["ssn"];
        $sql = "SELECT type FROM person WHERE ssn= $sn ";
                
        $result = mysqli_query($conn, $sql);
        if (mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
            }else{
                $conn->close();                
                return null;
                }

  

if($_SESSION["ssn"]!=null && $row["type"]=="0"){
 
?>
<html>
    <head>
    <title>Online Exam System</title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <link rel="stylesheet" type="text/css" href="css.css" />
</head>
<body id="top">
    
<div class="wrapper row1">
  <div id="header" class="clear">
    
      <h1><a href="student.php">Online Exam System</a></h1>
      <p>Isik University</p>
 
              <?php
               $sql2 = "SELECT p.ssn FROM person as p WHERE ssn = $sn";
        $result2 = mysqli_query($conn, $sql2);
        if (mysqli_num_rows($result2) > 0) {
        $row2 = mysqli_fetch_assoc($result2);
            }else{
                $conn->close();                
                return null;
                }
                $nme = $row2["ssn"];
               ?>
        <div class="wrapper2 row1">  
        <a href="student.php" > <h4 style="color: darkorange;">Student : <?php echo $nme ?></h4></a>
        </div> 

   <br> </br>
   </div>
  </div>
</div>

        

            
                <!-- CONTENT -->
                <div class="wrapper row4">
 <div id="container" class="clear"> 
          
            </div>   
<?php 
              
$num =$_SESSION["num"];

             
              
  ?>
                   
      <?php  
    $sql3 = "SELECT e.questionid,e.examid,e.question,e.answer1,e.answer2,e.answer3,e.answer4 FROM question as e WHERE e.type ='1'and e.examid='$num'";
    $result39 = mysqli_query($conn, $sql3);
     $sql31 = "SELECT e.questionid,e.examid,e.question,e.answer1,e.answer2 FROM question as e WHERE e.type ='2' and e.examid='$num'";
    $result31 = mysqli_query($conn, $sql31);
    
  
      if($row39 = mysqli_fetch_assoc($result39)) {
        
          ?>
     
      <form method = "post" action = "studentexamApply.php">
          <table align="center" ></table>
           <?php
           $eid=$row39["examid"];
           
                  $qid=$row39["questionid"];
                    ?>
          <tr><td> <label><input type="hidden" name="qid" value=" <?php echo  $qid?>"/></label><br/></td></tr>
         
          <tr><td>  <label><input type="hidden" name="eid" value=" <?php echo  $eid?>"/></label><br/></td></tr>
         
            <tr>
                <td>question -> </td>
                <td>
                    <?php
                    echo "".$row39["question"];
                    ?>
                </td>
                </tr><br/>
                <tr>
                 <td>
                     <label><input type="radio" name="answer" value="1"/> A </label>
                  </td>
                <td>
                    <?php
                    echo "".$row39["answer1"];
                    ?>
                </td> </tr><tr><br/>
                 <td>
                     <label><input type="radio" name="answer" value="2"/> B </label>
                            </td>
                <td>
                    <?php
                    echo "".$row39["answer2"];
                    ?>
                </td> </tr><tr><br/>
                <td>
                    <label><input type="radio" name="answer" value="3"/> C </label>
                            </td>
                 <td>
                    <?php
                    echo "".$row39["answer3"];
                    ?>
                </td> </tr><tr><br/>
                 <td>
                     <label><input type="radio" name="answer" value="4"/> D </label>
                            </td>
                <td>
                    <?php
                    echo "".$row39["answer4"];
                    ?>
                </td> 
            </tr><br/>
                             <tr>
                            
                            <td>
                                <input type = "submit" name = "add" value = "next question" style="width: 125px;"/>
                                
                            </td>                
                        </tr>
             </table>
      </form>
          
          <?php }  elseif($row4 = mysqli_fetch_assoc($result31)) { ?>
          <form method = "post" action = "studentexamApply.php">
        <table align="center"  >
          <?php
           $eid=$row39["examid"];
                  $qid=$row4["questionid"];
                    ?>
          
          <label><input type="hidden" name="qid" value=" <?php echo  $qid?>"/></label><br/>
           <label><input type="hidden" name="eid" value=" <?php echo  $eid?>"/></label><br/>
            <tr>
                <td>question -></td>
                <td>
                    <?php
                    echo "".$row4["question"];
                    ?>
                </td>
                </tr><tr>
                    <td> </td>
                 <td>
                     <label><input type="radio" name="correct" value="true"/> true</label><br/>
                 
                </td> <td> 
                 
                     <label><input type="radio" name="correct" value="false"/> false</label><br/>
                
                </td>
               
            </tr>
        <tr>
                            <td></td> 
                            <td>
                                <input type = "submit" name = "add" value = "next question" style="width: 125px;"/>
                                
                            </td>                
                        </tr>
             </table>
          </form>
           
     <?php } else {?>
     
           	 <form method = "post" action = "doldurulacak">
        
        <tr>
                            <td></td> 
                            <td>
                                <input type = "submit" name = "add" value = "finish" style="width: 125px;"/>
                                
                            </td>                
                        </tr>
             </table>
          </form>
<?php } ?>
    
<br> </br><br> </br><br> </br><br> </br><br> </br>
               

               <div class="wrapper row1 a ">
             <div id="footer" class="clear"> 
                  <h2><br />Isik University</h2>
                    <address>
                     Sile Kampusu/Mesrutiyet Koyu<br />
                     Sile/Istanbul<br />
                     34980
                     </address>
      <ul>
        <li><strong>Tel:</strong> 0 216 712 14 60</li>
        <li><strong>Fax:</strong> 0 216 710 28 73</li>
        <li class="last"><strong>Email:</strong> <a href="mailto:info@isikun.edu.tr">info@isikun.edu.tr</a></li>
      </ul>
  </div>
</div>

</body>
</html>

<?php  
}else{
    echo "<h3 style='color:red'>You have no permission for this page!</h3>";
    echo "<h3 style='color:red'><a href='index.php'>Click for redirection to homepage</a></h3>";
}
?>
