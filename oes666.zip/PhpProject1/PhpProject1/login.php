<!DOCTYPE html>

<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>Login Page</title>
</head>
<body> 
    <?php
        function Redirect($url, $permanent = false)
{
    if (headers_sent() === false)
    {
    	header('Location: ' . $url, true, ($permanent === true) ? 301 : 302);
    }

    exit();
}

        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "onlineexam";
        $conn = new mysqli($servername, $username, $password, $dbname);
        if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
        }
    
        $ssn = $_POST["ssn"];
        $pwd = $_POST["pwd"];
        if($ssn == null)
        Redirect('loginError.html', false);
        
        $sql = "SELECT type FROM person WHERE ssn = $ssn "; 
        $result = mysqli_query($conn, $sql);
        if (mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        }

        
        $sql2 = "SELECT pwd FROM person WHERE ssn = $ssn "; 
        $result2 = mysqli_query($conn, $sql2);
        session_start();
        if (mysqli_num_rows($result2) > 0) {
        $row2 = mysqli_fetch_assoc($result2);
        }
        $sql2 = "SELECT status FROM person WHERE ssn = $ssn "; 
        $result2 = mysqli_query($conn, $sql2);
        session_start();
        if (mysqli_num_rows($result2) > 0) {
        $row3 = mysqli_fetch_assoc($result2);
        }
        else{
          Redirect('loginError.html', false);  
        }
        
       
        if( $row["type"] == "0" && $row2["pwd"] == $pwd ) {
            
                
                $_SESSION["ssn"] = $ssn;
                Redirect('student.php', false); 
                $conn->close(); 

            }
         else if ( $row["type"] == "1" && $row2["pwd"] == $pwd && $row3["status"] == 'Accept') {

                $_SESSION["ssn"] = $ssn;
                Redirect('teacherPage.php', false);
                $conn->close(); 
        }  
        else if ( $row["type"] == "2" && $row2["pwd"] == $pwd ) {
            echo "güzel";

                $_SESSION["ssn"] = $ssn;
                Redirect('adminPage.php', false);
                $conn->close(); 
        }  
         else {

           Redirect('loginError.html', false);
            $conn->close(); 
            
        }
        
        
        
    
    
  ?>
  
</body>
</html>
