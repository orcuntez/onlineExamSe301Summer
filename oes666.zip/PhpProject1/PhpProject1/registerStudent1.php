<!DOCTYPE html>


<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>Apply Page</title>
</head>
<body>
    <?php
     function Redirect($url, $permanent = false)
{
    if (headers_sent() === false)
    {
    	header('Location: ' . $url, true, ($permanent === true) ? 301 : 302);
    }

    exit();
}

    
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "onlineexam";
    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
    
    } 
    
    
    try {
         $sn = $_POST["ssn"];
         $a1 = $_POST["name"];
         $a2 = $_POST["bdate"];
         $a22=date("1925-01-01 00:00:00");
         $a23=date("2011-01-01 00:00:00");
         $a3 = $_POST["sex"];
         $a4 = $_POST["address"];
         $type=0;
         $pwd = $_POST["pwd"];
         
         if (    $sn == null ||strlen((string)$sn)!='11'||
                 $a1 == null||
                 $a2 == null|| $a22 >= $a2 || $a23 <= $a2  ||
                 $a4 == null ||
                 $pwd == null||strlen($pwd)<='5') {
             Redirect('loginError.html', false);
    }



    $sql = "INSERT INTO person (ssn, fullname,bdate,sex,address,type,pwd)
            VALUES ('$sn', '$a1', '$a2', '$a3', '$a4','$type','$pwd')";
            
            if ($conn->query($sql) == TRUE) {
           
                Redirect('registerApply.php', false);
            } else {
               echo "Error: " . $sql . "<br>" . $conn->error;
    }
    $conn->close();
        
} catch (Exception $ex) {
    echo ex;
        
}


        
         
    ?>
</body>
</html>
