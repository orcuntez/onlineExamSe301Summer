<!DOCTYPE html>

    <?php
    

    
        function Redirect($url, $permanent = false)
{
    if (headers_sent() === false)
    {
    	header('Location: ' . $url, true, ($permanent === true) ? 301 : 302);
    }

    exit();
}
session_start();
    if($_SESSION["ssn"]==null)
        Redirect('index.php', false); 


        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "onlineexam";
        $conn = new mysqli($servername, $username, $password, $dbname);
        if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
        }
        
        $sn = $_SESSION["ssn"];
        $sql = "SELECT type FROM person WHERE ssn= $sn ";
                
        $result = mysqli_query($conn, $sql);
        if (mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
            }else{
                $conn->close();                
                return null;
                }
        

if($_SESSION["ssn"]!=null && $row["type"]=="1"){
  

?>
<html>
    <head>
    <title>Online Exam System</title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <link rel="stylesheet" type="text/css" href="css.css" />
</head>
<body id="top">
    
<div class="wrapper row1">
  <div id="header" class="clear">
    
      <h1><a href="teacherPage.php">Online Exam System</a></h1>
      <p>Isik University</p>
   
   
  </div>
</div>
        <div class="row5" id="footer"> 
    <ul>	
        <br>      
        <a href="teacherPage.php">Home</a> &emsp;
             <a href="registerStudent.html">Register Student </a>&emsp;
              <a href="changePassword.php">Change Password</a>&emsp;
              <a href="index.php">logout</a></ul>
               </br>
            </ul>
   </div> 

            
        
               <div class="wrapper row4">
 <div id="container" class="clear"> 
                <!-- CONTENT -->
                <h2>Login</h2>
             
                <br /><br />

                <!-- END CONTENT -->

            </div>   
               

               
            <?php
               $sql2 = "SELECT fullname FROM person WHERE ssn = $sn";
        $result2 = mysqli_query($conn, $sql2);
        if (mysqli_num_rows($result2) > 0) {
        $row2 = mysqli_fetch_assoc($result2);
            }else{
                $conn->close();                
                return null;
                }
                $nme = $row2["fullname"];
               ?>
            
              
                
                <li><a href="createExam1.php">create exam</a></li>&emsp;
                <li><a href="createAnnouncement.php">create announcement</a></li>
                
                
                <font size="4">
                <br></br>
                <a href="teacherPage.php"> <h4 style="color: darkorange;">teacher : <?php echo $nme ?></h4></a>
 <br></br> <br></br> <br></br>

               

 
            <div class="wrapper row1 a ">
             <div id="footer" class="clear"> 
                  <h2><br />Isik University</h2>
                    <address>
                     Sile Kampusu/Mesrutiyet Koyu<br />
                     Sile/Istanbul<br />
                     34980
                     </address>
      <ul>
        <li><strong>Tel:</strong> 0 216 712 14 60</li>
        <li><strong>Fax:</strong> 0 216 710 28 73</li>
        <li class="last"><strong>Email:</strong> <a href="mailto:info@isikun.edu.tr">info@isikun.edu.tr</a></li>
      </ul>
    
    

  </div>
</div>

</body>
</html>
<?php
}else{
    echo "<h3 style='color:red'>You have no permission for this page!</h3>";
    echo "<h3 style='color:red'><a href='index.php'>Click for redirection to homepage</a></h3>";
}
?>
