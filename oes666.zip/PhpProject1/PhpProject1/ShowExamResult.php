<!DOCTYPE html>

   
<html>
    <head>
    <title>Online Exam System</title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <link rel="stylesheet" type="text/css" href="css.css" />
</head>
<body id="top">
    
<div class="wrapper row1">
  <div id="header" class="clear">
    
      <h1><a href="index.php">Online Exam System</a></h1>
      <p>Isik University</p>
  
   
  </div>
</div>
<div class="wrapper row4">
         <div id="container" class="clear"> 
             <?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "onlineexam";
    $conn = new mysqli($servername,$username,$password,$dbname);
    
    if($conn -> connect_error) {
        die ("Connection failed :" .$conn -> connect_error);
    }
    $sql = " Select midterm1,midterm2,midterm3,final from grade ";
    $result = $conn -> query($sql);
    
    if($result -> num_rows > 0) {
        while($row = $result -> fetch_assoc()){
            echo "<br> midterm1:" .$row["midterm1"]. " </br> midterm2:" .$row["midterm2"]. "</br> midterm3:" .$row["midterm3"]. "</br>final:" .$row["final"]. "<br>";
        }
    } else {
        echo "0 results";
    }
    $conn -> close();
    
            
    ?>
           
        </div>    
   </div> 
 <div class="wrapper ">
             <div id="footer" class="clear"> 
                  <h2><br />Isik University</h2>
                    <address>
                     Sile Kampusu/Mesrutiyet Koyu<br />
                     Sile/Istanbul<br />
                     34980
                     </address>
      <ul>
        <li><strong>Tel:</strong> 0 216 712 14 60</li>
        <li><strong>Fax:</strong> 0 216 710 28 73</li>
        <li class="last"><strong>Email:</strong> <a href="mailto:info@isikun.edu.tr">info@isikun.edu.tr</a></li>
      </ul>
    
    

            </div>
        </div>
    </body>
    </html>
    
