<!DOCTYPE html>

    <?php
    

    
        function Redirect($url, $permanent = false)
{
    if (headers_sent() === false)
    {
    	header('Location: ' . $url, true, ($permanent === true) ? 301 : 302);
    }

    exit();
}
session_start();
    if($_SESSION["ssn"]==null)
        Redirect('index.php', false); 


        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "onlineexam";
        $conn = new mysqli($servername, $username, $password, $dbname);
        if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
        }
        
        $sn = $_SESSION["ssn"];
        $sql = "SELECT type FROM person WHERE ssn= $sn ";
                
        $result = mysqli_query($conn, $sql);
        if (mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        $typ = $row["type"];
            }else{
                $conn->close();                
                return null;
                }
        

if($_SESSION["ssn"]!=null){
    

?>
<html>
    <head>
    <title>Online Exam System</title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <link rel="stylesheet" type="text/css" href="css.css" />
</head>
<body id="top">
    
<div class="wrapper row1">
  <div id="header" class="clear">
    
       <ul>	
                <!-- MENU -->
                 <?php if($typ == "2"){ ?>
                <li class="selected"><a href="adminPage.php"><font size="6">Online Exam System</font></a></li>
                    <?php } ?>    
                <?php if($typ == "1"){ ?>
                <li class="selected"><a href="teacherPage.php"><font size="6">Online Exam System</font></a></li>
                    <?php } ?>    
                <?php if($typ == "0"){ ?>
                <li class="selected"><a href="student.php"><font size="6">Online Exam System</font></a></li>
                    <?php  } ?>  

             </ul>
      <p>Isik University</p>

  </div>
</div>

        
    
      
   
   

        <div class="wrapper row1">
            <div id="header" class="clear">
              <ul>	
                <!-- MENU -->
                 <?php if($typ == "2"){ ?>
                <li class="selected"><a href="adminPage.php">Home</a></li>
                    <?php } ?>    
                <?php if($typ == "1"){ ?>
                <li class="selected"><a href="teacherPage.php">Home</a></li>
                    <?php } ?>    
                <?php if($typ == "0"){ ?>
                <li class="selected"><a href="student.php">Home</a></li>
                    <?php  } ?>  

             </ul>
            </div>
        </div> 

            
          <div class="wrapper row4 ">
            <div id="footer footbox" class="clear" > 
                <br> </br><br> </br>
                <h2>Change Password</h2>  
                
                <br></br>
                
<?php 
    $sql5 = "SELECT pwd,ssn from person where ssn = '$sn' ";
    $result5 = mysqli_query($conn, $sql5);
    $row5 = mysqli_fetch_assoc($result5);
    $pwd = $row5["pwd"];
    ?>
          
       
        <table>
            <form method="post" action="changePasswordApply.php"> 
            
            <td> Old Password (*):</td>
            <td><input type="text" name="pwd" value= <?php echo "".$row5["pwd"] ?> /></td>
            <td>                              
            <input type="hidden" name="ssn" value="<?php echo "".$row5["ssn"]?>"> 
            <input type="submit" name="Apply" value="Apply">
            </td>
     

            </form>
        
        
       
            </table>
        

                <font size="4">
&emsp;

          <?php
               $sql2 = "SELECT name FROM person WHERE ssn = $sn";
        $result2 = mysqli_query($conn, $sql2);
        if (mysqli_num_rows($result2) > 0) {
        $row2 = mysqli_fetch_assoc($result2);
            }else{
                $conn->close();                
                return null;
                }
                $nme = $row2["name"];
               ?>
                 <?php if($typ == "2"){ ?>
                <a href="adminPage.php"> <h4 style="color: red;">admin name : <?php echo $nme ?></h4></a>
               <?php } ?>
               <?php if($typ == "1"){ ?>
                <a href="teacherPage.php"> <h4 style="color: green;">teacher: <?php echo $nme ?></h4></a>
               <?php } ?>
                <?php if($typ == "0"){ ?>
                <a href="student.php"> <h4 style="color: blue;">Student : <?php echo $nme ?></h4></a>
                <?php } ?>
               

              <br></br>
                 <br></br>
                 <br></br>
                 <br></br>
                 <br></br>
                
	
            </div>
          </div>	
       
           <div class="wrapper row5">
             <div id="footer" class="clear"> 
                  <h2><br />Isik University</h2>
                    <address>
                     Sile Kampusu/Mesrutiyet Koyu<br />
                     Sile/Istanbul<br />
                     34980
                     </address>
      <ul>
        <li><strong>Tel:</strong> 0 216 712 14 60</li>
        <li><strong>Fax:</strong> 0 216 710 28 73</li>
        <li class="last"><strong>Email:</strong> <a href="mailto:info@isikun.edu.tr">info@isikun.edu.tr</a></li>
      </ul>
    
    

  </div>
</div>
</body>
</html>
<?php
}else{
    echo "<h3 style='color:red'>You have no permission for this page!</h3>";
    echo "<h3 style='color:red'><a href='index.php'>Click for redirection to homepage</a></h3>";
}
?>
