<!DOCTYPE html>

<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>Apply Page</title>
</head>
<body>
    <?php
    function Redirect($url, $permanent = false, $type)
{
    if (headers_sent() === false)
    {
    	header('Location: ' . $url, true, ($permanent === true) ? 301 : 302);
    }

    exit();
}
    
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "onlineexam";
    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
    
    } 
                $sql2 = "SELECT p.ssn,p.fullname,p.pwd  FROM person as p WHERE status='waited'";
               
                $result2 = mysqli_query($conn, $sql2);
                    if (mysqli_num_rows($result2) > 0) {
                    $row2 = mysqli_fetch_assoc($result2);
                    }else{
                        $conn->close();                
                        return null;
                    }
                        $nme = $row2["fullname"];
                        $pwd= $row2["pwd"];
                        $ssn = $row2["ssn"];
                        $a2 = $_POST["click"];
         
       
         
           $sq2 = "INSERT INTO TEACHER(ssn,pwd) VALUES($ssn,$pwd)";
      
            $sql = "Update person set status='$a2' where ssn = $ssn ";
            
           
            if ($conn->query($sql) === TRUE &&$conn->query($sq2) === TRUE){
                
                Redirect("adminPage.php",false);
                    
                }else {
                echo "Error: " . $sql . "<br>" . $conn->error;
                    }
         
         $conn->close();
         
    ?>
</body>
</html>
