<!DOCTYPE html>
 <?php
    

    
        function Redirect($url, $permanent = false)
{
    if (headers_sent() === false)
    {
    	header('Location: ' . $url, true, ($permanent === true) ? 301 : 302);
    }

    exit();
}
session_start();
    if($_SESSION["ssn"]==null)
        Redirect('index.php', false); 


        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "onlineexam";
        $conn = new mysqli($servername, $username, $password, $dbname);
        if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
        }
        
        
        ?>
<html>
    <head>
    <title>Online Exam System</title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <link rel="stylesheet" type="text/css" href="css.css" />
</head>
<body id="top">
   
    
<div class="wrapper row1">
  <div id="header" class="clear">
    
      <h1><a href="index.php">Online Exam System</a></h1>
      <p>Isik University</p>
   <br> </br>
   
  </div>
</div>
     


        
               <div class="wrapper row4">
                 <div id="container" class="clear"> 
                <!-- CONTENT -->
                <h2>Register Student</h2>
                 <br></br>
            </div>   
           <div class="wrapper row4">
             <div id="footer footbox" class="clear"> 
                
                 <form method = "post" action = "ChooseExamApply.php">
                    <table>
                        <tr>
                            <td>
                                <label><font size="3">Enter the exam number:</font></label>
                            </td>
                        </tr>
                       
          
                        <tr>
                            <td>
                                <input type="number" name="num" >
                            </td>
                        </tr>
                        <tr>
                            <td>
    
                                <input type = "submit" name = "Enter" value = "Enter" style="width: 50px;"/>
                            </td>                
                        </tr>
                         


                    </table>
                </form>
                <br></br>
                
            
                
                
                <font size="4">


            </div>


            <div class="wrapper row1 a ">
             <div id="footer" class="clear"> 
                  <h2><br />Isik University</h2>
                    <address>
                     Sile Kampusu/Mesrutiyet Koyu<br />
                     Sile/Istanbul<br />
                     34980
                     </address>
      <ul>
        <li><strong>Tel:</strong> 0 216 712 14 60</li>
        <li><strong>Fax:</strong> 0 216 710 28 73</li>
        <li class="last"><strong>Email:</strong> <a href="mailto:info@isikun.edu.tr">info@isikun.edu.tr</a></li>
      </ul>
    
    

  </div>
</div>

</body>
</html>

