<!DOCTYPE html>

    <?php
    

    
        function Redirect($url, $permanent = false)
{
    if (headers_sent() === false)
    {
    	header('Location: ' . $url, true, ($permanent === true) ? 301 : 302);
    }

    exit();
}
session_start();
    if($_SESSION["ssn"]==null)
        Redirect('index.php', false); 


        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "onlineexam";
        $conn = new mysqli($servername, $username, $password, $dbname);
        if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
        }
        
        $sn = $_SESSION["ssn"];
        $sql = "SELECT type FROM person WHERE ssn= $sn ";
                
        $result = mysqli_query($conn, $sql);
        if (mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
            }else{
                $conn->close();                
                return null;
                }
        

if($_SESSION["ssn"]!=null && $row["type"]=="1"){
    
  
?>
<html>
    <head>
    <title>Online Exam System</title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <link rel="stylesheet" type="text/css" href="css.css" />
</head>
<body id="top">
    
<div class="wrapper row1">
  <div id="header" class="clear">
    
      <h1><a href="teacherPage.php">Online Exam System</a></h1>
      <p>Isik University</p>
   
   <br> </br>
  </div>
</div>
     

    
                 
           <div class="wrapper row4">
 <div id="container" class="clear"> 
     
     <form method = "post" action = "createExamApplyTF.php">
        
                    <table>
                        <tr>
                            <td>
                                <label>Qestion  </label>
                            </td>
                        
                            <td>
                                <input type="text" size="100" align="right" name="question" >
                            </td>
                            
                            </tr>
                            <tr>
                                <td>
                                    <label><input type="radio" name="true" value="true"/> true</label><br/>
                                    <label><input type="radio" name="true" value="false"/> false</label><br/>
    
                            </td>
                            </tr>
                            
                            
                            <td></td> 
                            <td>
                                <input type = "submit" name = "add" value = "add" style="width: 125px;" />
                                
                            </td>                
                        </tr>
                        
                    </table>
                               
                </form>
     </div>
              

            <?php
               $sql2 = "SELECT fullname FROM person WHERE ssn = $sn";
        $result2 = mysqli_query($conn, $sql2);
        if (mysqli_num_rows($result2) > 0) {
        $row2 = mysqli_fetch_assoc($result2);
            }else{
                $conn->close();                
                return null;
                }
                $nme = $row2["fullname"];
               ?>
             
    <a href="teacherPage.php"> <h4 style="color: darkorange;">teacher : <?php echo $nme ?></h4></a>
         


             <div class="wrapper row1 a ">
             <div id="footer" class="clear"> 
                  <h2><br />Isik University</h2>
                    <address>
                     Sile Kampusu/Mesrutiyet Koyu<br />
                     Sile/Istanbul<br />
                     34980
                     </address>
      <ul>
        <li><strong>Tel:</strong> 0 216 712 14 60</li>
        <li><strong>Fax:</strong> 0 216 710 28 73</li>
        <li class="last"><strong>Email:</strong> <a href="mailto:info@isikun.edu.tr">info@isikun.edu.tr</a></li>
      </ul>
    
    

  </div>
</div>

</body>
</html>
</body>
</html>
<?php
}else{
    echo "<h3 style='color:red'>You have no permission for this page!</h3>";
    echo "<h3 style='color:red'><a href='index.php'>Click for redirection to homepage</a></h3>";
}
?>
