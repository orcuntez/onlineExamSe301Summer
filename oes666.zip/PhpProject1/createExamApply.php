<!DOCTYPE html>

<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>Apply Page</title>
</head>
<body>
    <?php
    function Redirect($url, $permanent = false, $type)
{
    if (headers_sent() === false)
    {
    	header('Location: ' . $url, true, ($permanent === true) ? 301 : 302);
    }

    exit();
}
    
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "onlineexam";
    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
    
    } 
       $correct = $_POST["true"];
       if($correct==NULL){
      Redirect('loginError.html', false);
     }
        
         $question = $_POST["question"];
         $a1 = $_POST["answer1"];
         $a2 = $_POST["answer2"];
         $a3 = $_POST["answer3"];
         $a4 = $_POST["answer4"];
         $eid =-1;
         $type=1;
        
         if($question == null|| $a1 == null|| $a2 == null|| $a3 == null|| $a4 == null)
        Redirect('loginError.html', false);
         
         
         
         
      
            $sql = "INSERT INTO question (examid, answer1,answer2,answer3,answer4,correctanswer,type,question)
            VALUES ('$eid', '$a1', '$a2', '$a3', '$a4','$correct ','$type ','$question')";
            
            
        
           
            if ($conn->query($sql) === TRUE){
                
                Redirect('createExam1.php', false); 
                    
                }else {
                echo "Error: " . $sql . "<br>" . $conn->error;
                    }
         
         $conn->close();
         
    ?>
</body>
</html>
