<!DOCTYPE html>

<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>Apply Page</title>
</head>
<body>
    <?php
    function Redirect($url, $permanent = false)
{
    if (headers_sent() === false)
    {
    	header('Location: ' . $url, true, ($permanent === true) ? 301 : 302);
    }

    exit();
}
    
    
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "onlineexam";
    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
    
    } 
    
                        
            
         $title = $_POST["title"];
         $info = $_POST["info"];
        $aid=$_POST["ssn"];
         $sql21 = "SELECT teacherid  FROM teacher WHERE ssn='$aid'";
                     $result3 = mysqli_query($conn, $sql21);
                    if (mysqli_num_rows($result3) > 0) {
                    $row1 = mysqli_fetch_assoc($result3);
                      
                    }else{
                        $conn->close();                
                        return null;
                    }
                     
                        $sql31 = $row1["teacherid"];
                     
                     
       
         if (    $title == null ||
                 $info == null) {
             Redirect('loginError.html', false);
    }

      
            $sql = "INSERT INTO announcement (teacherid,title, info)
            VALUES ('$sql31','$title', '$info' )";
           
            
            if ($conn->query($sql) === TRUE){
                 
                Redirect('AnnouncementApply.html', false); 
                    
                }else {
                echo "Error: " . $sql . "<br>" . $conn->error;
                    }
            $conn->close();
         
    ?>
</body>
</html>
