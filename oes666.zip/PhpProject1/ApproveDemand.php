<!DOCTYPE html>
    <?php
    

    
        function Redirect($url, $permanent = false)
{
    if (headers_sent() === false)
    {
    	header('Location: ' . $url, true, ($permanent === true) ? 301 : 302);
    }

    exit();
}
session_start();
    if($_SESSION["ssn"]==null)
        Redirect('index.php', false); 


        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "onlineexam";
        $conn = new mysqli($servername, $username, $password, $dbname);
        if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
        }
        
        $sn = $_SESSION["ssn"];
        $sql = "SELECT type FROM person WHERE ssn= $sn ";
                
        $result = mysqli_query($conn, $sql);
        if (mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
            }else{
                $conn->close();                
                return null;
                }
        

if($_SESSION["ssn"]!=null && $row["type"]=="2"){
     

?>
<html>
    <head>
    <title>Online Exam System</title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <link rel="stylesheet" type="text/css" href="css.css" />
</head>
<body id="top">
    
<div class="wrapper row1">
  <div id="header" class="clear">
    <br> </br>
      <h1><a href="adminPage.php">Online Exam System</a></h1>
      <p>Isik University</p>
   
   
  </div>
</div>
                <?php
                $sql2 = "SELECT p.ssn,p.fullname,p.status,p.pwd  FROM person as p WHERE status='waited'";
                 
                $result2 = mysqli_query($conn, $sql2);
                while($row2 = mysqli_fetch_assoc($result2)) { 
                     $result3 = mysqli_query($conn, $sql2);
                    if (mysqli_num_rows($result3) > 0) {
                    $row1 = mysqli_fetch_assoc($result3);
                      
                    }else{
                        $conn->close();                
                        return null;
                    }
                     
                        $nme = $row2["fullname"];
                        $sts = $row2["status"];
                        $pwd= $row2["pwd"];
                        $ssn = $row2["ssn"];
                      
                   ?>

                    
            </div>  </div>  
           <div class="wrapper row3 a1">
 <div id="footbox " class="clear">  
     
     
     <form method = "post" action = "ApproveDemandApply.php">
       
                    <table>
                        <tr>
                            <tr>
                            <td>
                                <label><font size="3">Full Name :</font></label>
                                <?php
                                               echo $nme;
                                ?>
                            </td>
                        
                            
                            </tr>
                            
                            <tr>
                            <td>
                                <label><font size="3">Status :</font></label>
                                <?php
                                               echo $sts;
                                ?>
                            </td>
                            </tr>
                            
                            <tr>
                                <td>
                                  <label><input type="radio" name="click" value="Accept"/> Accept</label><br/>
                            </td>
                            
                            
                                <td>
                                  <label><input type="radio" name="click" value="Reject"/>Reject</label><br/>
                            </td>
                            
                            </tr>
                            
                           
                        <tr>
                            <td></td> 
                            <td>
                                <input type = "submit" name = "send" value = "send" style="width: 125px;"/>
                                
                            </td>                
                        </tr>
                        <?php  } ?> 
                    </table>
                                
                </form>
     </div>
</div>
       
            

  <div class="wrapper row1 a ">
             <div id="footer" class="clear"> 
                  <h2><br />Isik University</h2>
                    <address>
                     Sile Kampusu/Mesrutiyet Koyu<br />
                     Sile/Istanbul<br />
                     34980
                     </address>
      <ul>
        <li><strong>Tel:</strong> 0 216 712 14 60</li>
        <li><strong>Fax:</strong> 0 216 710 28 73</li>
        <li class="last"><strong>Email:</strong> <a href="mailto:info@isikun.edu.tr">info@isikun.edu.tr</a></li>
      </ul>
    
    

  </div>
</div>

</body>
</html>
<?php
}else{
    echo "<h3 style='color:red'>You have no permission for this page!</h3>";
    echo "<h3 style='color:red'><a href='index.php'>Click for redirection to homepage</a></h3>";
}
?>

