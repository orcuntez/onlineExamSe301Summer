<!DOCTYPE html>

    <?php
    

    
        function Redirect($url, $permanent = false)
{
    if (headers_sent() === false)
    {
    	header('Location: ' . $url, true, ($permanent === true) ? 301 : 302);
    }

    exit();
}
session_start();
    if($_SESSION["ssn"]==null)
        Redirect('login.php', false); 


        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "onlineexam";
        $conn = new mysqli($servername, $username, $password, $dbname);
        if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
        }
        
        $sn = $_SESSION["ssn"];
        $sql = "SELECT type FROM person WHERE ssn= $sn ";
                
        $result = mysqli_query($conn, $sql);
        if (mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        $typ = $row["type"];
            }else{
                $conn->close();                
                return null;
                }
        

if($_SESSION["ssn"]!=null){

?>
<html>
    <head>
    <title>Online Exam System</title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <link rel="stylesheet" type="text/css" href="css.css" />
</head>
<body id="top">
    
<div class="wrapper row1">
  <div id="header" class="clear">
    <br> </br>
      <ul>	
                <!-- MENU -->
                 <?php if($typ == "2"){ ?>
                <li class="selected"><a href="adminPage.php"><font size="6">Online Exam System</font></a></li>
                    <?php } ?>    
                <?php if($typ == "1"){ ?>
                <li class="selected"><a href="teacherPage.php"><font size="6">Online Exam System</font></a></li>
                    <?php } ?>    
                <?php if($typ == "0"){ ?>
                <li class="selected"><a href="student.php"><font size="6">Online Exam System</font></a></li>
                    <?php  } ?>  

             </ul>
      <p>Isik University</p>
   
    <br> </br> <br> </br>
  </div>
</div>
 
      <div class="wrapper row4 ">
            <div id="footer footbox" class="clear" > ,
    
               <br></br><br> </br><br></br><br></br> <br></br><br> </br>
                
                <h2>Password is changed successfuly!</h2>
                <p>You can return back.</p>
                <?php if($typ == "2"){ ?>
                <p><form method="post" action="adminPage.php"><input type="submit" name="Back" value="Back" style="width: 125px;"/></form>
                <?php } ?>
                <?php if($typ == "1"){ ?>
                <p><form method="post" action="teacherPage.php"><input type="submit" name="Back" value="Back" style="width: 125px;"/></form>
                <?php } ?>
                <?php if($typ == "0"){ ?>
                <p><form method="post" action="student.php"><input type="submit" name="Back" value="Back" style="width: 125px;"/></form>
                <?php } ?>
            
                	

           	
        </div>
    
 <br></br><br> </br><br></br><br></br> <br></br><br> </br><br></br>
             
  </div>
       <div class="wrapper row1 a ">
             <div id="footer" class="clear"> 
                  <h2><br />Isik University</h2>
                    <address>
                     Sile Kampusu/Mesrutiyet Koyu<br />
                     Sile/Istanbul<br />
                     34980
                     </address>
      <ul>
        <li><strong>Tel:</strong> 0 216 712 14 60</li>
        <li><strong>Fax:</strong> 0 216 710 28 73</li>
        <li class="last"><strong>Email:</strong> <a href="mailto:info@isikun.edu.tr">info@isikun.edu.tr</a></li>
      </ul>
    
    

  </div>
</div>

</body>
</html>

<?php
}else{
    echo "<h3 style='color:red'>You have no permission for this page!</h3>";
    echo "<h3 style='color:red'><a href='index.php'>Click for redirection to homepage</a></h3>";
}
?>
