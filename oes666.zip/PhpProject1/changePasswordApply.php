<!DOCTYPE html>

<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>Apply Page</title>
</head>
<body>
    <?php
    function Redirect($url, $permanent = false)
{
    if (headers_sent() === false)
    {
    	header('Location: ' . $url, true, ($permanent === true) ? 301 : 302);
    }

    exit();
}
    
    
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "onlineexam";
    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
    
    } 


         $sn = $_POST["ssn"];
         $pwd = $_POST["pwd"];

 
         
            $sql = "update person set pwd = '$pwd' where ssn = '$sn' ";
            
            if ($conn->query($sql) === TRUE){
                
                Redirect('changePwd.php', false); 
                    
                }else {
                echo "Error: " . $sql . "<br>" . $conn->error;
                    }
            $conn->close();
         
    ?>
</body>
</html>
