
<!DOCTYPE html>

<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>Apply Page</title>
</head>
<body>
    <?php
    function Redirect($url, $permanent = false, $type)
{
    if (headers_sent() === false)
    {
    	header('Location: ' . $url, true, ($permanent === true) ? 301 : 302);
    }

    exit();
}
    
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "onlineexam";
    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
    
    } 
      
       $qid = $_POST["qid"];
       $num = $_POST["num"];
         $an = 1;
            $correct = $_POST["answer"];
        
         if($qid == null)
        Redirect('loginError.html', false);
      $sgl7="Update question set answered='$an' where questionid = '1' ";
            $sql = "INSERT INTO answeredquestion (questionid,answer)
            VALUES ('$qid', '$correct')";
          ?> 
    
           <?php  
            if ($conn->query($sql) === TRUE){
                
                Redirect('studentexam.php', false); 
                    
                }else {
                echo "Error: " . $sql . "<br>" . $conn->error;
                    }
         
         $conn->close();
         
    ?>
</body>
</html>






