-- phpMyAdmin SQL Dump
-- version 4.5.2
-- http://www.phpmyadmin.net
--
-- Anamakine: 127.0.0.1
-- Üretim Zamanı: 21 Tem 2016, 17:09:05
-- Sunucu sürümü: 5.7.9
-- PHP Sürümü: 5.6.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: `project1`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `announcement`
--

DROP TABLE IF EXISTS `announcement`;
CREATE TABLE IF NOT EXISTS `announcement` (
  `title` varchar(100) DEFAULT NULL,
  `info` varchar(10000) DEFAULT NULL,
  `type` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `announcement`
--

INSERT INTO `announcement` (`title`, `info`, `type`) VALUES
('tery', 'eyes', 1),
('Ä±ugjhhv', 'gcgc', 1),
('6juyt', 'ehurtdj', 1),
('ewtewrsy', 'radsfa\r\nfdsag', 1),
('hasan ', 'fiÅŸi Ã§Ä±kar\r\ntamammÄ±', 1),
('hasan ', 'fiÅŸi Ã§Ä±kar\r\ntamammÄ±', 1),
('hasan ', 'fiÅŸi Ã§Ä±kar\r\ntamammÄ±', 1),
('hasan ', 'fiÅŸi Ã§Ä±kar\r\ntamammÄ±', 1),
('hasan ', 'fiÅŸi Ã§Ä±kar\r\ntamammÄ±', 1),
('34dgsddsav', 'rwqkutÄ±ugfkb\r\nwekfusgku\r\nwehfkjsdhg\r\nwegfkdjshg\r\nhfgdsh\r\nkdjgfdsjkÃ¼\r\nhdfdsÃ¼\r\nhfkdshÃ¼', 1),
('durukan', 'meÅŸe \r\nhasan \r\nmurat\r\n', 1);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `exam`
--

DROP TABLE IF EXISTS `exam`;
CREATE TABLE IF NOT EXISTS `exam` (
  `question` varchar(500) DEFAULT NULL,
  `answer1` varchar(500) DEFAULT NULL,
  `answer2` varchar(500) DEFAULT NULL,
  `answer3` varchar(500) DEFAULT NULL,
  `answer4` varchar(500) DEFAULT NULL,
  `type` int(11) DEFAULT NULL,
  `x` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `exam`
--

INSERT INTO `exam` (`question`, `answer1`, `answer2`, `answer3`, `answer4`, `type`, `x`) VALUES
('qqqqqqqqqqqqqqq', 'true', 'false', 'false', '', 2, 2),
('qqqqqqqqqqqqqqq', 'aaaaaaaaaa', 'aaa', 'aaa', 'aaaa', 2, 1),
('zzzzzzzzzzzzzzzzzz', 'true', 'false', 'true', '', 1, 2),
('qqqqqqqqqqqqqqq', 'aaaaaaaaaa', 'aaaaaaaa', 'aaaaaaaa', 'aaaaaaaaa', 1, 1);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `person`
--

DROP TABLE IF EXISTS `person`;
CREATE TABLE IF NOT EXISTS `person` (
  `ssn` varchar(45) NOT NULL,
  `name` varchar(45) NOT NULL,
  `bdate` varchar(45) NOT NULL,
  `sex` varchar(45) NOT NULL,
  `address` varchar(45) NOT NULL,
  `type` varchar(45) NOT NULL,
  `pwd` varchar(45) NOT NULL,
  PRIMARY KEY (`ssn`),
  UNIQUE KEY `ssn_UNIQUE` (`ssn`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `person`
--

INSERT INTO `person` (`ssn`, `name`, `bdate`, `sex`, `address`, `type`, `pwd`) VALUES
('00000001', 'durukan', '26071991', 'm', 'beykoz', '0', 'aaa'),
('01', '321', '3221-03-12', '3wer', 'erew', '0', '123456'),
('01234567', '321', '3221-03-12', '3wer', 'erew', '0', '123456'),
('012345678', '321', '3221-03-12', '3wer', 'erew', '0', '123456'),
('012345678904', '321', '3221-03-12', '3wer', 'erew', '0', '123456'),
('013', '321', '3221-03-12', '3wer', 'erew', '0', '123456'),
('0134', '321', '3221-03-12', '3wer', 'erew', '0', '123456'),
('01345678900', '321', '3221-03-12', '3wer', 'erew', '0', '123456'),
('01345678901', '321', '2222-03-12', '3wer', 'erew', '0', '123456'),
('01345678902', '321', '2222-03-12', '3wer', 'erew', '0', '123456'),
('01345678903', '321', '2000-03-12', '3wer', 'erew', '0', '123456'),
('01345678904', '321', '2000-03-12', 'f', 'erew', '0', '123456'),
('01345678905', '321', '2000-03-12', 'fm', 'erew', '0', '123456'),
('01345678906', '321', '2000-03-12', 'm', 'erew', '0', '123456'),
('01345678907', '321', '2000-03-12', 'f', 'erew', '0', '123456'),
('10000001', 'orcun', '26071991', 'm', 'çan', '1', '111'),
('11111111', 'hasan', '45121991', 'orta', 'maaraş', '2', 'aaa'),
('123', 'sdsa', '1111-11-11', 'dd', 'fafsaac', '0', '111'),
('1234', '321', '3221-03-12', '3wer', 'erew', '0', '123456'),
('12345678902', 'sadsaf', '1993-11-11', 'male', 'dshdbsfg', '1', '123456'),
('12345678903', 'sadsaf', '1993-11-11', 'male', 'dshdbsfg', '1', '123456'),
('12722252252', 'vxz', '1988-11-11', 'male', 'fdvxc', '0', '123456'),
('14324', 'wfewds', '0444-03-04', 'fs', 'sfds', '0', '123456'),
('234', 'efds', '3211-03-12', 'wdw', 'dd', '0', 'wdw'),
('32722252200', 'sdasf', '1967-11-11', 'male', 'dszc', '1', '123456'),
('32722252201', 'sdasf', '1967-11-11', 'male', 'dszc', '1', '123456'),
('32722252202', 'sdasf', '1967-11-11', 'male', 'dszc', '1', '123456'),
('32722252203', 'sdasf', '1967-11-11', 'male', 'dszc', '1', '123456'),
('32722252211', 'fsdaf', '2000-11-11', 'male', 'gfxb', '1', '123456'),
('32722252250', 'sdasf', '1967-11-11', 'male', 'dszc', '1', '123456'),
('32722252252', 'orcun', '1994-01-01', 'male', 'slkcgnlfjnb', '1', '111111'),
('32722252253', 'czcxz', '1956-11-11', 'female', 'sdfdg', '1', '123456'),
('32722252257', 'sdasf', '1967-11-11', 'male', 'dszc', '1', '123456'),
('32722252258', 'sdasf', '1967-11-11', 'male', 'dszc', '1', '123456'),
('5324', 'fsdf', '1223-11-11', 'ef', 'eweffwef', '2', '324342');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
